// src/app/api/payroll/[id]/pdf/route.ts
// Real server-rendered PDF (Puppeteer) with the company letterhead
// header/footer repeating on every page — same pattern as the letters
// module. Replaces the old approach of returning raw HTML.
import { NextRequest, NextResponse } from 'next/server'
import { BRAND } from '@/lib/branding'
import { prisma } from '@/lib/prisma'
import { getRequestSession } from '@/lib/auth'
import { Settings } from '@/lib/settings'
import { buildPayslipBody, CompanyInfo } from '@/lib/businessPdf'
import { renderBusinessPdf } from '@/lib/pdfRenderer'
import { isCompanyWideRole } from '@/lib/permissions'

export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const session = await getRequestSession(req)
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  try {
    const payslip = await prisma.payslip.findUnique({
      where: { id: id },
      include: {
        employee: {
          include: {
            user: { select: { name: true, email: true } },
            department: { select: { name: true } },
          },
        },
      },
    })

    if (!payslip) return NextResponse.json({ error: 'Not found' }, { status: 404 })

    // Non-admins can only download their own payslip — matches the payroll list scoping.
    if (!isCompanyWideRole(session.role) && payslip.employee.userId !== session.userId) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
    }

    const MONTH_NAMES = ['January','February','March','April','May','June','July','August','September','October','November','December']

    const [companyName, companyAddress, companyPhone, companyEmail, companyGst, companyLogoUrl, companySignatureUrl] = await Promise.all([
      Settings.companyName(),
      Settings.companyAddress(),
      Settings.companyPhone(),
      Settings.companyEmail(),
      Settings.companyGst(),
      Settings.companyLogo(),
      Settings.companySignature(),
    ])

    const company: CompanyInfo = {
      companyName: companyName || BRAND.name,
      companyAddress: companyAddress || undefined,
      companyPhone: companyPhone || undefined,
      companyEmail: companyEmail || undefined,
      companyGst: companyGst || undefined,
      companyLogoUrl: companyLogoUrl || undefined,
      companySignatureUrl: companySignatureUrl || undefined,
    }

    const bodyHtml = buildPayslipBody({
      month: MONTH_NAMES[payslip.month - 1] || String(payslip.month),
      year: payslip.year,
      paidDays: Math.round((payslip.workingDays || 0) - (payslip.lopDays || 0)),
      payDate: new Date(payslip.generatedAt || payslip.createdAt).toLocaleDateString('en-GB', { timeZone: 'Asia/Kolkata' }),
      employee: {
        name: payslip.employee.user.name,
        employeeId: payslip.employee.employeeId,
        position: payslip.employee.position || '—',
        department: payslip.employee.department?.name || '—',
      },
      bank: {
        bankName: payslip.employee.bankName || undefined,
        accountNumber: payslip.employee.accountNumber || undefined,
      },
      // basicSalary/hra/conveyance/medical/specialAllow are the FULL monthly
      // values (not prorated). We show the full breakup + a single LOP
      // deduction line for the days not paid — that's the standard payslip
      // format and it keeps the numbers from double-counting the LOP.
      earnings: {
        basic: payslip.basicSalary,
        hra: payslip.hra,
        conveyance: payslip.conveyance,
        medical: payslip.medical,
        specialAllow: payslip.specialAllow,
        bonus: payslip.otherEarnings,
      },
      deductions: {
        advance: payslip.otherDeduct,
        lop: Math.max(0, (payslip.basicSalary + payslip.hra + payslip.conveyance + payslip.medical + payslip.specialAllow) - payslip.grossSalary),
        lopDays: payslip.lopDays || 0,
        esi: payslip.esi,
        pf: payslip.pf,
        professionTax: payslip.professionTax,
        tds: payslip.tds,
      },
      grossEarnings: payslip.basicSalary + payslip.hra + payslip.conveyance + payslip.medical + payslip.specialAllow + payslip.otherEarnings,
      totalDeduction: payslip.totalDeduct + payslip.otherDeduct + Math.max(0, (payslip.basicSalary + payslip.hra + payslip.conveyance + payslip.medical + payslip.specialAllow) - payslip.grossSalary),
      netSalary: payslip.netSalary,
      company,
    })

    let pdfBuffer: Buffer
    try {
      pdfBuffer = await renderBusinessPdf(bodyHtml, `Payslip ${MONTH_NAMES[payslip.month - 1]} ${payslip.year}`)
    } catch (err) {
      console.error('Payslip PDF render failed:', err)
      return NextResponse.json({ error: 'Failed to generate PDF' }, { status: 500 })
    }

    const safeName = (payslip.employee.user.name || 'employee').replace(/[^a-zA-Z0-9]+/g, '-')
    const fileName = `Payslip-${safeName}-${payslip.month}-${payslip.year}.pdf`

    return new NextResponse(pdfBuffer as unknown as BodyInit, {
      headers: {
        'Content-Type': 'application/pdf',
        'Content-Disposition': `inline; filename="${fileName}"`,
        'Cache-Control': 'no-store',
      },
    })
  } catch (error) {
    console.error('Payslip PDF error:', error)
    return NextResponse.json({ error: 'Failed' }, { status: 500 })
  }
}
