// src/app/api/import-export/route.ts
import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requireAuth, getRequestSession, hasMinRole } from '@/lib/auth'
import { errorResponse, successResponse } from '@/lib/api'
import { dateOnly, getISTDateParts } from '@/lib/attendanceDate'
import { Settings } from '@/lib/settings'
import { getTeamScope } from '@/lib/teamScope'
import { managerClientWhere, normPhone, loadPhoneMap } from '@/lib/clientAccess'
import { generateClientCode, generateLeadNumber } from '@/lib/idgen'
import { canSeeBeyondOwn, isCompanyWideRole } from '@/lib/permissions'

const isAdminRole = (role: string) => isCompanyWideRole(role)
const VALID_STATUSES = ['NEW', 'NOT_INTERESTED', 'FOLLOW_UP', 'RINGING', 'MEETING_SCHEDULED', 'CALLBACK', 'CONVERTED', 'CLOSED']

function toCsv(data: any[], filename: string) {
  if (data.length === 0) {
    return new NextResponse('No data', {
      headers: { 'Content-Type': 'text/csv', 'Content-Disposition': `attachment; filename="${filename}.csv"` },
    })
  }
  const headers = Object.keys(data[0]).join(',')
  const rows = data.map(row =>
    Object.values(row).map(v => `"${String(v ?? '').replace(/"/g, '""')}"`).join(',')
  )
  const csv = [headers, ...rows].join('\n')
  return new NextResponse('\uFEFF' + csv, {
    headers: {
      'Content-Type': 'text/csv; charset=utf-8',
      'Content-Disposition': `attachment; filename="${filename}.csv"`,
    },
  })
}

// GET: Export data as CSV/JSON
export async function GET(req: NextRequest) {
  const session = await getRequestSession(req)
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { searchParams } = new URL(req.url)
  const type = searchParams.get('type') // clients, payments, attendance, leads, employees
  const format = searchParams.get('format') || 'csv'

  try {
    let data: any[] = []
    let filename = `${type}-export`

    switch (type) {
      case 'clients': {
        // Admin + TL (MANAGER) only
        if (!canSeeBeyondOwn(session.role)) {
          return errorResponse('Forbidden', 403)
        }
        const search = searchParams.get('search')
        const status = searchParams.get('status')
        const state = searchParams.get('state')
        const marketingPersonId = searchParams.get('marketingPersonId')
        const telecallerId = searchParams.get('telecallerId')
        const serviceCatalogId = searchParams.get('serviceCatalogId')
        const serviceName = searchParams.get('serviceName')
        const expiry = searchParams.get('expiry')
        const dateField = searchParams.get('dateField') || 'createdAt'
        const dateFrom = searchParams.get('dateFrom')
        const dateTo = searchParams.get('dateTo')

        const where: any = {}
        if (status) where.status = status
        if (state) where.state = state
        if (marketingPersonId) where.marketingPersonId = marketingPersonId
        if (telecallerId) where.telecallerId = telecallerId
        if (search) {
          where.OR = [
            { clientCode: { contains: search } },
            { clientName: { contains: search } },
            { companyName: { contains: search } },
            { phone: { contains: search } },
            { email: { contains: search } },
          ]
        }
        if (dateFrom || dateTo) {
          const field = dateField === 'onboardingDate' ? 'onboardingDate' : 'createdAt'
          where[field] = {}
          if (dateFrom) where[field].gte = new Date(dateFrom)
          if (dateTo) where[field].lte = new Date(dateTo + 'T23:59:59')
        }
        const svc: any = {}
        if (serviceName) svc.serviceName = { contains: serviceName }
        if (serviceCatalogId) svc.serviceCatalogId = serviceCatalogId
        if (expiry) {
          const todayStart = new Date(new Date().toISOString().split('T')[0])
          if (expiry === 'expired') svc.expiryDate = { lt: todayStart }
          else if (expiry === 'none') svc.expiryDate = null
          else if (expiry === 'active') { svc.expiryDate = { gte: todayStart }; svc.status = 'ACTIVE' }
          else {
            const days = parseInt(expiry)
            if (!isNaN(days)) {
              const until = new Date(todayStart); until.setUTCDate(until.getUTCDate() + days); until.setUTCHours(23, 59, 59, 999)
              svc.expiryDate = { gte: todayStart, lte: until }
            }
          }
        }
        if (Object.keys(svc).length) where.services = { some: svc }

        // Same TL (MANAGER) visibility as the clients list — only their own
        // added/assigned clients export, Admin/Super Admin export everything.
        if (session.role === 'MANAGER') {
          where.AND = [...(where.AND || []), await managerClientWhere(session.userId)]
        }

        const clients = await prisma.client.findMany({
          where,
          include: { services: true, assignedTo: { select: { name: true } } },
          orderBy: { createdAt: 'desc' },
        })
        // A client can hold many services, so each one is exported as
        // "Name | start | end | amount | cycle | status", pipe-separated inside
        // the cell and semicolon-separated between services. The same format is
        // accepted back on import.
        const d = (x: Date | null | undefined) => (x ? x.toISOString().split('T')[0] : '')
        const encodeService = (sv: any) =>
          [sv.serviceName, d(sv.startDate), d(sv.expiryDate), sv.amount ?? 0, sv.billingCycle || 'ONE_TIME', sv.status || 'ACTIVE'].join(' | ')

        data = clients.map(c => ({
          ClientCode: c.clientCode,
          CompanyName: c.companyName,
          ContactName: c.clientName,
          Phone: c.phone,
          AltPhone: c.altPhone || '',
          Email: c.email || '',
          GSTIN: c.gstNo || '',
          Address: c.address || '',
          City: c.city || '',
          State: c.state || '',
          Pincode: c.pincode || '',
          Status: c.status,
          AssignedTo: c.assignedTo?.name || '',
          OnboardingDate: d(c.onboardingDate),
          ServicesCount: c.services.length,
          // Legacy plain list, kept so old sheets still open cleanly
          Services: c.services.map(sv => sv.serviceName).join('; '),
          // Full round-trippable version used by the importer
          ServiceDetails: c.services.map(encodeService).join(' ;; '),
          ServiceStartDates: c.services.map(sv => d(sv.startDate)).join('; '),
          ServiceEndDates: c.services.map(sv => d(sv.expiryDate) || '-').join('; '),
          CreatedAt: c.createdAt.toISOString().split('T')[0],
        }))
        filename = 'clients-export'
        break
      }

      case 'payments': {
        const payments = await prisma.payment.findMany({
          include: {
            invoice: { include: { client: { select: { companyName: true } } } },
          },
          orderBy: { paidAt: 'desc' },
        })
        data = payments.map(p => ({
          InvoiceNumber: p.invoice?.invoiceNumber || '',
          Client: p.invoice?.client?.companyName || '',
          Amount: p.amount,
          Method: p.method,
          Reference: p.reference || '',
          PaidAt: p.paidAt.toISOString().split('T')[0],
        }))
        filename = 'payments-export'
        break
      }

      case 'attendance': {
        // Same filters as the attendance list so "filter → export" matches on-screen data
        const departmentId = searchParams.get('departmentId')
        const status = searchParams.get('status')
        const month = searchParams.get('month')       // YYYY-MM
        const date = searchParams.get('date')         // YYYY-MM-DD
        const dateFrom = searchParams.get('dateFrom')
        const dateTo = searchParams.get('dateTo')
        const search = searchParams.get('search')

        const where: any = {}
        if (date) {
          where.date = dateOnly(date)
        } else if (month) {
          const [y, m] = month.split('-').map(Number)
          where.date = { gte: new Date(y, m - 1, 1), lte: new Date(y, m, 0, 23, 59, 59) }
        } else if (dateFrom || dateTo) {
          where.date = {}
          if (dateFrom) where.date.gte = new Date(dateFrom)
          if (dateTo) where.date.lte = new Date(dateTo + 'T23:59:59')
        }
        if (status) where.status = status

        // Role scope: non-admins (TL / dept head / manager) only get their own team
        if (!isAdminRole(session.role)) {
          const scope = await getTeamScope((session as any).userId)
          if (!scope.visibleIds.length) return toCsv([], 'attendance-export')
          where.employeeId = { in: scope.visibleIds }
        }

        const intersect = (ids: string[]) => {
          where.employeeId = where.employeeId?.in
            ? { in: where.employeeId.in.filter((id: string) => ids.includes(id)) }
            : { in: ids }
        }

        // Department filter is admin-only (TLs already scoped to their own dept/team)
        if (departmentId && isAdminRole(session.role)) {
          const deptEmps = await prisma.employee.findMany({ where: { departmentId }, select: { id: true } })
          intersect(deptEmps.map(e => e.id))
        }
        if (search) {
          const users = await prisma.user.findMany({ where: { name: { contains: search } }, select: { id: true } })
          const emps = await prisma.employee.findMany({ where: { userId: { in: users.map(u => u.id) } }, select: { id: true } })
          intersect(emps.map(e => e.id))
        }

        const attendance = await prisma.attendance.findMany({
          where,
          include: {
            employee: {
              include: {
                user: { select: { name: true } },
                department: { select: { name: true } },
              },
            },
          },
          orderBy: [{ date: 'desc' }, { punchIn: 'desc' }],
          take: 5000,
        })
        data = attendance.map(a => ({
          EmployeeID: a.employee.employeeId,
          Name: a.employee.user.name,
          Department: a.employee.department?.name || '',
          Date: a.date.toISOString().split('T')[0],
          PunchIn: a.punchIn ? new Date(a.punchIn).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }) : '',
          PunchOut: a.punchOut ? new Date(a.punchOut).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }) : '',
          HoursWorked: a.hoursWorked ?? 0,
          Late: a.isLate ? 'Yes' : 'No',
          'LateBy(min)': a.isLate ? (a.lateBy ?? 0) : 0,
          WorkMode: a.workMode,
          Status: a.status,
        }))

        // Append a summary row: total records + total late marks
        const totalLate = attendance.filter(a => a.isLate).length
        if (data.length > 0) {
          data.push({
            EmployeeID: '', Name: '', Department: '', Date: '',
            PunchIn: '', PunchOut: '', HoursWorked: '',
            Late: `TOTAL LATE: ${totalLate}`, 'LateBy(min)': '',
            WorkMode: '', Status: `TOTAL RECORDS: ${attendance.length}`,
          })
        }
        filename = 'attendance-export'
        break
      }

      case 'employees': {
        // Admin-only rich export. status = active | inactive | all (default all)
        if (!canSeeBeyondOwn(session.role)) {
          return errorResponse('Forbidden', 403)
        }
        const statusParam = (searchParams.get('status') || 'all').toLowerCase()
        const where: any = {}
        if (statusParam === 'active') where.user = { isActive: true }
        else if (statusParam === 'inactive') where.user = { isActive: false }

        const employees = await prisma.employee.findMany({
          where,
          include: {
            user: { select: { name: true, phone: true, avatar: true, dateOfBirth: true, isActive: true } },
            department: { select: { name: true } },
          },
          orderBy: { createdAt: 'desc' },
        })
        data = employees.map(e => ({
          'Date Of Joining': e.joiningDate ? e.joiningDate.toISOString().split('T')[0] : '',
          Name: e.user.name,
          Designation: e.position || '',
          Department: e.department?.name || '',
          'Blood Group': e.bloodGroup || '',
          'Phone Number': e.user.phone || '',
          'Emergency Number': e.emergencyPhone || '',
          Address: [e.address, e.city, e.state, e.pincode].filter(Boolean).join(', '),
          Photos: e.user.avatar || '',
          'Employee ID': e.employeeId,
          DOB: e.dateOfBirth
            ? e.dateOfBirth.toISOString().split('T')[0]
            : (e.user.dateOfBirth ? e.user.dateOfBirth.toISOString().split('T')[0] : ''),
          Status: e.user.isActive ? 'Active' : 'Inactive',
        }))
        filename = `employees-${statusParam}-export`
        break
      }

      case 'leads': {
        // Mirror /api/leads' filters + role-based visibility so
        // "filter on screen → export" gives exactly what's shown.
        const status = searchParams.get('status')
        const source = searchParams.get('source')
        const assignedToId = searchParams.get('assignedToId')
        const search = searchParams.get('search')
        const dateFrom = searchParams.get('dateFrom')
        const dateTo = searchParams.get('dateTo')

        const where: any = {}
        if (status) where.status = status
        if (source) where.source = source
        if (search) {
          where.OR = [
            { leadNumber: { contains: search } },
            { clientName: { contains: search } },
            { companyName: { contains: search } },
            { clientPhone: { contains: search } },
            { clientEmail: { contains: search } },
          ]
        }
        if (dateFrom || dateTo) {
          where.createdAt = {}
          if (dateFrom) where.createdAt.gte = new Date(dateFrom)
          if (dateTo) where.createdAt.lte = new Date(dateTo + 'T23:59:59')
        }

        // Role-based visibility (same rules as the leads list)
        if (session.role === 'TELECALLER') {
          where.assignedToId = session.userId
        } else if (session.role === 'MARKETING_EXECUTIVE') {
          where.meetingAssignedToId = session.userId
        } else if (session.role === 'EMPLOYEE') {
          return toCsv([], 'leads-export')
        }
        if (assignedToId && canSeeBeyondOwn(session.role)) {
          where.assignedToId = assignedToId
        }

        const leads = await prisma.lead.findMany({
          where,
          include: {
            createdBy: { select: { name: true } },
            assignedTo: { select: { name: true } },
            meetingAssignedTo: { select: { name: true } },
          },
          orderBy: { createdAt: 'desc' },
        })
        data = leads.map(l => ({
          LeadNumber: l.leadNumber,
          Name: l.clientName,
          Phone: l.clientPhone,
          Email: l.clientEmail || '',
          Company: l.companyName || '',
          Address: [l.address, l.area, l.city, l.state, l.pincode].filter(Boolean).join(', '),
          Source: l.source,
          Service: l.service || '',
          Status: l.status,
          Remark: l.remark || '',
          MeetingPerson: l.meetingAssignedTo?.name || '',
          CreatedBy: l.createdBy?.name || '',
          AssignedTo: l.assignedTo?.name || '',
          CreatedAt: l.createdAt.toISOString().split('T')[0],
        }))
        filename = dateFrom || dateTo
          ? `leads-export-${dateFrom || 'start'}_to_${dateTo || 'end'}`
          : 'leads-export'
        break
      }

      case 'attendance-summary': {
        // Monthly per-employee summary for ACTIVE users.
        // ?month=YYYY-MM  (defaults to current month)
        if (!canSeeBeyondOwn(session.role)) {
          return errorResponse('Forbidden', 403)
        }
        const monthParam = searchParams.get('month') || new Date().toISOString().slice(0, 7)
        const [y, m] = monthParam.split('-').map(Number)
        const total = new Date(Date.UTC(y, m, 0)).getUTCDate()
        // Attendance.date is a UTC-midnight DATE — build the window in UTC (local-time
        // boundaries leaked the previous month's last day into this month on IST servers).
        const monthStart = new Date(Date.UTC(y, m - 1, 1))
        const monthEnd = new Date(Date.UTC(y, m - 1, total, 23, 59, 59))

        // Same day rules as payroll: weekly offs + company holidays are not working days,
        // future days are not counted, mid-month joiners count from their joining date.
        const [offDays, holidayList] = await Promise.all([Settings.weeklyOffDays(), Settings.companyHolidays()])
        const pad = (n: number) => String(n).padStart(2, '0')
        const holidaySet = new Set((Array.isArray(holidayList) ? holidayList : []).map(h => String(h).slice(0, 10)))
        const ist = getISTDateParts(new Date())
        const isCurrent = ist.year === y && ist.month + 1 === m
        const isFuture = y > ist.year || (y === ist.year && m > ist.month + 1)
        const lastDay = isFuture ? 0 : isCurrent ? ist.day : total
        const companyDays: number[] = []
        for (let d = 1; d <= lastDay; d++) {
          if (offDays.includes(new Date(Date.UTC(y, m - 1, d)).getUTCDay())) continue
          if (holidaySet.has(`${y}-${pad(m)}-${pad(d)}`)) continue
          companyDays.push(d)
        }

        const empWhere: any = { user: { isActive: true, role: { notIn: ['ADMIN', 'SUPER_ADMIN'] } }, OR: [{ joiningDate: null }, { joiningDate: { lte: monthEnd } }] }
        // Non-admin (TL / manager): summary only for employees under them
        if (!isAdminRole(session.role)) {
          const scope = await getTeamScope((session as any).userId)
          if (!scope.visibleIds.length) return toCsv([], `attendance-summary-${monthParam}`)
          empWhere.id = { in: scope.visibleIds }
        }

        const employees = await prisma.employee.findMany({
          where: empWhere,
          include: {
            user: { select: { name: true } },
            department: { select: { name: true } },
          },
          orderBy: { employeeId: 'asc' },
        })
        const empIds = employees.map(e => e.id)

        const [atts, leaves] = await Promise.all([
          prisma.attendance.findMany({
            where: { employeeId: { in: empIds }, date: { gte: monthStart, lte: monthEnd } },
            select: { employeeId: true, date: true, status: true, workMode: true, isLate: true, punchIn: true },
          }),
          prisma.leave.findMany({
            where: { employeeId: { in: empIds }, status: 'APPROVED', startDate: { lte: monthEnd }, endDate: { gte: monthStart } },
            select: { employeeId: true, duration: true, startDate: true, endDate: true },
          }),
        ])
        const attBy: Record<string, any[]> = {}, lvBy: Record<string, any[]> = {}
        atts.forEach(a => (attBy[a.employeeId] ||= []).push(a))
        leaves.forEach(l => (lvBy[l.employeeId] ||= []).push(l))
        const dayNum = (d: Date | string) => new Date(d).getUTCDate()
        const dayStamp = (d: Date | string) => { const x = new Date(d); return Date.UTC(x.getUTCFullYear(), x.getUTCMonth(), x.getUTCDate()) }

        data = employees.map(e => {
          let joinDay = 1
          if (e.joiningDate) {
            const j = new Date(e.joiningDate)
            if (j.getUTCFullYear() === y && j.getUTCMonth() + 1 === m) joinDay = j.getUTCDate()
          }
          const workSet = new Set(companyDays.filter(d => d >= joinDay))
          const rows = attBy[e.id] || []
          // Extra office-closed days marked on the employee's attendance
          rows.forEach(r => { if (r.status === 'HOLIDAY') workSet.delete(dayNum(r.date)) })
          const onWork = rows.filter(r => workSet.has(dayNum(r.date)))

          const present = onWork.filter(r => r.status === 'PRESENT').length
          const halfDay = onWork.filter(r => r.status === 'HALF_DAY').length
          const late = onWork.filter(r => r.isLate).length
          const wfh = onWork.filter(r => r.workMode === 'WFH' && r.punchIn).length

          // Leave days = approved full-day leave dates inside the month, on working days only
          // (clipped to the month, no Sundays/holidays, no double count with a punched-in day).
          const punched = new Set(onWork.filter(r => r.punchIn || r.status === 'PRESENT' || r.status === 'HALF_DAY').map(r => dayNum(r.date)))
          const leaveSet = new Set<number>()
          let shortLeave = 0
          for (const lv of lvBy[e.id] || []) {
            if (lv.duration === 'SHORT_HOURLY') {
              const sd = new Date(lv.startDate)
              if (sd.getUTCFullYear() === y && sd.getUTCMonth() + 1 === m) shortLeave++
              continue
            }
            const s = dayStamp(lv.startDate), en = dayStamp(lv.endDate)
            for (const d of workSet) {
              const t = Date.UTC(y, m - 1, d)
              if (t >= s && t <= en && !punched.has(d)) leaveSet.add(d)
            }
          }
          onWork.forEach(r => { if (r.status === 'LEAVE' && !r.punchIn) leaveSet.add(dayNum(r.date)) })

          const accounted = new Set<number>([...onWork.map(r => dayNum(r.date)), ...leaveSet])
          const absent = Math.max(0, workSet.size - accounted.size)

          return {
            EmployeeID: e.employeeId,
            Name: e.user.name,
            Department: e.department?.name || '',
            'Working days': workSet.size,
            Present: present,
            Leave: leaveSet.size,
            Absent: absent,
            Late: late,
            WFH: wfh,
            'Short leave': shortLeave,
            'Half days': halfDay,
          }
        })
        filename = `attendance-summary-${monthParam}`
        break
      }

      default:
        return errorResponse('Invalid export type')
    }

    if (format === 'csv') return toCsv(data, filename)
    return NextResponse.json({ data, total: data.length })
  } catch (error) {
    console.error('Export error:', error)
    return errorResponse('Export failed')
  }
}

// POST: Import leads or clients from CSV/JSON
export async function POST(req: NextRequest) {
  // Leads can be imported by any staff member (Telecaller and up) — it was
  // previously locked to MANAGER+ which is why a telecaller's import
  // always failed with a silent 403. Client import stays MANAGER+ only,
  // checked below inside that branch specifically.
  const auth = await requireAuth(req)
  if (auth instanceof Response) return auth
  const session = await getRequestSession(req)

  const body = await req.json()

  // ---- Import clients ----
  if (Array.isArray(body.clients)) {
    if (!hasMinRole((session as any).role, 'MANAGER')) {
      return errorResponse('Forbidden', 403)
    }
    const rows = body.clients
    if (rows.length === 0) return errorResponse('No clients provided')

    const created: any[] = []
    const errors: any[] = []
    let servicesCreated = 0

    // Departments (for auto-assigning the dept head as project manager) and the
    // service catalog (so an imported service name inherits its department).
    const [catalog, depts] = await Promise.all([
      prisma.serviceCatalog.findMany({ select: { id: true, name: true, departmentId: true, billingCycle: true, basePrice: true } }),
      prisma.department.findMany({ select: { id: true, name: true, manager: { select: { userId: true } } } }),
    ])
    const deptHeadByDeptId: Record<string, string | null> = Object.fromEntries(
      depts.map(d => [d.id, d.manager?.userId || null])
    )
    const catalogByName: Record<string, any> = Object.fromEntries(
      catalog.map(c => [c.name.trim().toLowerCase(), c])
    )
    const deptByName: Record<string, string> = Object.fromEntries(
      depts.map(d => [d.name.trim().toLowerCase(), d.id])
    )

    const parseDate = (v: any): Date | null => {
      if (!v) return null
      const t = String(v).trim()
      if (!t || t === '-') return null
      // dd-mm-yyyy / dd/mm/yyyy
      const m = t.match(/^(\d{1,2})[-\/](\d{1,2})[-\/](\d{4})$/)
      if (m) return new Date(Number(m[3]), Number(m[2]) - 1, Number(m[1]))
      const d = new Date(t)
      return isNaN(d.getTime()) ? null : d
    }

    /**
     * Accepts either:
     *   ServiceDetails : "SEO | 2026-01-01 | 2026-12-31 | 12000 | MONTHLY | ACTIVE ;; Website | ..."
     *   or the simple trio: Services / ServiceStartDates / ServiceEndDates (";"-separated, index-matched)
     *   or a single service via ServiceName / StartDate / EndDate columns.
     */
    const parseServices = (row: any) => {
      const out: any[] = []

      const details = row.ServiceDetails || row.serviceDetails
      if (details && String(details).trim()) {
        for (const chunk of String(details).split(';;')) {
          const parts = chunk.split('|').map((x: string) => x.trim())
          if (!parts[0]) continue
          out.push({
            serviceName: parts[0],
            startDate: parseDate(parts[1]),
            expiryDate: parseDate(parts[2]),
            amount: Number(parts[3]) || 0,
            billingCycle: (parts[4] || 'ONE_TIME').toUpperCase(),
            status: (parts[5] || 'ACTIVE').toUpperCase(),
            departmentName: parts[6] || '',
          })
        }
        return out
      }

      const names = String(row.Services || row.services || row.ServiceName || row.serviceName || '')
        .split(';').map((x: string) => x.trim()).filter(Boolean)
      if (!names.length) return out

      const starts = String(row.ServiceStartDates || row.serviceStartDates || row.StartDate || row.startDate || '')
        .split(';').map((x: string) => x.trim())
      const ends = String(row.ServiceEndDates || row.serviceEndDates || row.EndDate || row.endDate || row.ExpiryDate || '')
        .split(';').map((x: string) => x.trim())
      const amounts = String(row.ServiceAmounts || row.serviceAmounts || row.Amount || row.amount || '')
        .split(';').map((x: string) => x.trim())

      names.forEach((name: string, idx: number) => {
        out.push({
          serviceName: name,
          startDate: parseDate(starts[idx] ?? starts[0]),
          expiryDate: parseDate(ends[idx] ?? ends[0]),
          amount: Number(amounts[idx] ?? amounts[0]) || 0,
          billingCycle: String(row.BillingCycle || row.billingCycle || 'ONE_TIME').toUpperCase(),
          status: 'ACTIVE',
          departmentName: String(row.Department || row.department || ''),
        })
      })
      return out
    }

    const phoneMap = await loadPhoneMap()
    for (let i = 0; i < rows.length; i++) {
      const row = rows[i]
      const companyName = row.companyName || row.CompanyName || row.company
      const clientName = row.clientName || row.ContactName || row.contactName || row.name
      const phone = row.phone || row.Phone
      if (!companyName || !clientName || !phone) {
        errors.push({ row: i + 1, error: 'Company name, client name and phone required' })
        continue
      }
      const pn = normPhone(phone)
      if (phoneMap.has(pn)) {
        errors.push({ row: i + 1, error: `Phone already exists (${phoneMap.get(pn)})` })
        continue
      }
      try {
        const client = await prisma.client.create({
          data: {
            clientCode: await generateClientCode(),
            companyName, clientName,
            phone: String(phone),
            email: (row.email || row.Email) ? String(row.email || row.Email).toLowerCase() : null,
            address: row.address || row.Address || null,
            city: row.city || row.City || null,
            state: row.state || row.State || null,
            gstNo: row.gstNo || row.GSTIN || null,
            pincode: row.pincode || row.Pincode || null,
            altPhone: row.altPhone || row.AltPhone ? String(row.altPhone || row.AltPhone) : null,
            status: (row.status || row.Status || 'ACTIVE').toUpperCase(),
            onboardingDate: (() => {
              const d = parseDate(row.onboardingDate || row.OnboardingDate)
              return d || new Date()
            })(),
            createdById: (session as any).userId,
          },
        })
        created.push(client)
        phoneMap.set(pn, client.clientCode)

        // ---- services for this client (multiple supported) ----
        for (const sv of parseServices(row)) {
          try {
            const cat = catalogByName[sv.serviceName.trim().toLowerCase()]
            const departmentId =
              (sv.departmentName && deptByName[String(sv.departmentName).trim().toLowerCase()]) ||
              cat?.departmentId ||
              null

            const clientService = await prisma.clientService.create({
              data: {
                clientId: client.id,
                serviceCatalogId: cat?.id || null,
                serviceName: sv.serviceName,
                departmentId,
                startDate: sv.startDate || new Date(),
                expiryDate: sv.expiryDate,
                amount: sv.amount || cat?.basePrice || 0,
                billingCycle: sv.billingCycle || cat?.billingCycle || 'ONE_TIME',
                status: ['ACTIVE', 'PAUSED', 'CANCELLED', 'EXPIRED'].includes(sv.status) ? sv.status : 'ACTIVE',
              },
            })
            servicesCreated++

            // Same rule as the UI: the handling department's head becomes the
            // project manager automatically.
            const headUserId = departmentId ? deptHeadByDeptId[departmentId] : null
            if (headUserId) {
              await prisma.projectAssignment.create({
                data: { clientServiceId: clientService.id, managerId: headUserId, role: 'MANAGER', isActive: true },
              })
            }
          } catch {
            errors.push({ row: i + 1, error: `Client created but service "${sv.serviceName}" failed` })
          }
        }
      } catch {
        errors.push({ row: i + 1, error: 'Failed to create client (duplicate or invalid data)' })
      }
    }

    return successResponse({ imported: created.length, servicesCreated, errors }, created.length)
  }

  // ---- Import leads ----
  const { leads } = body

  if (!Array.isArray(leads) || leads.length === 0) {
    return errorResponse('No leads provided')
  }

  try {
    const created: any[] = []
    const errors: any[] = []
    const warnings: any[] = []

    for (let i = 0; i < leads.length; i++) {
      const row = leads[i]
      const clientName = String(row.clientName || row.name || '').trim()
      const clientPhone = String(row.clientPhone || row.phone || '').trim()
      if (!clientName || !clientPhone) {
        errors.push({ row: i + 1, error: 'Name and phone required' })
        continue
      }
      const statusRaw = String(row.status || row.Status || '').trim().toUpperCase()
      if (statusRaw && !VALID_STATUSES.includes(statusRaw)) {
        warnings.push({ row: i + 1, error: `Status "${row.status || row.Status}" not recognized — set to NEW` })
      }
      const status = statusRaw && VALID_STATUSES.includes(statusRaw) ? statusRaw : 'NEW'
      let createdLead
      let lastErr: any = null
      for (let attempt = 0; attempt < 3; attempt++) {
        try {
          createdLead = await prisma.lead.create({
            data: {
              leadNumber: await generateLeadNumber(),
              clientName,
              clientPhone,
              clientEmail: row.clientEmail || row.email ? String(row.clientEmail || row.email) : null,
              companyName: row.companyName || row.company ? String(row.companyName || row.company) : null,
              address: row.address || row.Address || null,
              source: row.source || 'OTHER',
              service: row.service || null,
              status,
              remark: row.remark || row.Remark || null,
              createdById: (session as any).userId,
              assignedToId: (session as any).userId,
            },
          })
          break
        } catch (createErr: any) {
          lastErr = createErr
          const isLeadNumberCollision = createErr?.code === 'P2002' && createErr?.meta?.target?.includes?.('leadNumber')
          if (isLeadNumberCollision && attempt < 2) continue
          break
        }
      }
      if (createdLead) {
        created.push(createdLead)
      } else {
        console.error(`[leads import] row ${i + 1} failed:`, lastErr)
        const reason = lastErr?.code === 'P2002'
          ? `Duplicate value (${lastErr?.meta?.target || 'unique field'})`
          : lastErr?.message
            ? String(lastErr.message).split('\n').pop()?.slice(0, 200)
            : 'Unknown error'
        errors.push({ row: i + 1, error: `Failed to create lead — ${reason}` })
      }
    }

    return successResponse({ imported: created.length, errors, warnings }, created.length)
  } catch (err) {
    console.error('[leads import] failed:', err)
    return errorResponse('Import failed')
  }
}