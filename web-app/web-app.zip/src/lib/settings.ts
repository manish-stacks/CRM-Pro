// src/lib/settings.ts
// Simple typed helper for the Setting key-value store.
// Supports strings, numbers, booleans, and JSON blobs.
import { prisma } from './prisma'
import { BRAND } from './branding'

// In-memory cache — settings rarely change, cheap to re-read
type Cache = { at: number; value: any }
const cache = new Map<string, Cache>()
const TTL_MS = 60_000 // 60s

// Overloads: passing a defaultValue guarantees a non-undefined return —
// this is what was missing, so every Settings.xyz(50)-style call across the
// app (payroll %, thresholds, etc.) was typed as "possibly undefined" even
// though it can never actually be undefined at runtime.
export async function getSetting<T = string>(key: string, defaultValue: T): Promise<T>
export async function getSetting<T = string>(key: string): Promise<T | undefined>
export async function getSetting<T = string>(key: string, defaultValue?: T): Promise<T | undefined> {
  const now = Date.now()
  const hit = cache.get(key)
  if (hit && now - hit.at < TTL_MS) return hit.value

  try {
    const row = await prisma.setting.findUnique({ where: { key } })
    if (!row) {
      if (defaultValue !== undefined) cache.set(key, { at: now, value: defaultValue })
      return defaultValue
    }
    // Try JSON parse; if fails treat as string
    let parsed: any = row.value
    try { parsed = JSON.parse(row.value) } catch { /* keep raw */ }
    cache.set(key, { at: now, value: parsed })
    return parsed as T
  } catch {
    return defaultValue
  }
}

export async function setSetting(key: string, value: any, category = 'general') {
  const serialized = typeof value === 'string' ? value : JSON.stringify(value)
  await prisma.setting.upsert({
    where: { key },
    update: { value: serialized, category },
    create: { key, value: serialized, category },
  })
  cache.set(key, { at: Date.now(), value })
}

export function invalidateSetting(key: string) {
  cache.delete(key)
}

export function invalidateAllSettings() {
  cache.clear()
}

// Convenience getters with sensible defaults
export const Settings = {
  companyName: () => getSetting<string>('company_name', BRAND.name),
  companyAddress: () => getSetting<string>('company_address', ''),
  companyPhone: () => getSetting<string>('company_phone', ''),
  companyEmail: () => getSetting<string>('company_email', BRAND.domain ? `info@${BRAND.domain}` : ''),
  companyGst: () => getSetting<string>('company_gst', ''),
  companyLogo: () => getSetting<string>('company_logo_url', BRAND.logoUrl),
  companySignature: () => getSetting<string>('company_signature_url', ''),
  holidayCalendarUrl: () => getSetting<string>('holiday_calendar_url', ''),
  currency: () => getSetting<string>('currency', 'INR'),
  currencySymbol: () => getSetting<string>('currency_symbol', '₹'),
  gstDefaultRate: () => getSetting<number>('gst_default_rate', 18),
  gstEnabledByDefault: () => getSetting<boolean>('gst_enabled_by_default', false),
  weeklyOffDays: () => getSetting<number[]>('weekly_off_days', [0]),
  workingHoursPerDay: () => getSetting<number>('working_hours_per_day', 8),
  halfDayThresholdHours: () => getSetting<number>('half_day_threshold_hours', 4),
  // Attendance office window + late-mark grace
  officeStartTime: () => getSetting<string>('office_start_time', '10:00'),   // 24h HH:mm
  officeEndTime: () => getSetting<string>('office_end_time', '18:30'),     // 6:30 PM
  lateGraceMinutes: () => getSetting<number>('late_grace_minutes', 10),       // grace till 10:10
  // Leave accrual + carry-forward
  leaveMonthlyAccrual: () => getSetting<number>('leave_monthly_accrual', 1),     // paid leaves earned per month
  leaveMaxCarryForward: () => getSetting<number>('leave_max_carryforward', 6),    // max leaves that can accumulate
  // "YYYY-MM" — wipe every balance and start accruing fresh from this month.
  // Empty/unset = keep counting from each employee's joining date (old behaviour).
  leaveBalanceStartMonth: () => getSetting<string>('leave_balance_start_month', ''),
  invoiceDueDays: () => getSetting<number>('invoice_due_days', 15),
  invoicePrefix: () => getSetting<string>('invoice_prefix', 'INV-'),
  paymentMethods: () => getSetting<string[]>('payment_methods', ['UPI', 'CASH', 'BANK_TRANSFER', 'CHEQUE', 'CARD']),
  timezone: () => getSetting<string>('timezone', 'Asia/Kolkata'),
  hrEmail: () => getSetting<string>('hr_email', BRAND.domain ? `hr@${BRAND.domain}` : ''),
  // Meeting slot booking — office window + slot size used to compute
  // available meeting slots per area for the telecaller's booking picker.
  meetingOfficeStart: () => getSetting<string>('meeting_office_start', '10:00'),
  meetingOfficeEnd: () => getSetting<string>('meeting_office_end', '18:30'),
  meetingSlotMinutes: () => getSetting<number>('meeting_slot_minutes', 90),
  // Notification kill-switches (desktop app section) — admin can stop
  // outgoing messages instantly without touching SMTP/WhatsApp credentials.
  emailEnabled: () => getSetting<boolean>('email_enabled', true),
  whatsappEnabled: () => getSetting<boolean>('whatsapp_enabled', true),

  // Desktop tracker (check-in/out + idle time) settings
  trackerEnabled: () => getSetting<boolean>('tracker_enabled', true),
  trackerIdleThresholdSec: () => getSetting<number>('tracker_idle_threshold_seconds', 300),

  // Payroll component percentages/amounts — admin-configurable so the salary
  // breakup (Basic/HRA/Conveyance/Medical/PF/ESI/Profession Tax/TDS) isn't
  // hardcoded in the payroll generator.
  payrollBasicPercent: () => getSetting<number>('payroll_basic_percent', 50),       // % of monthly salary
  payrollHraPercent: () => getSetting<number>('payroll_hra_percent', 20),         // % of basic
  payrollConveyanceAmount: () => getSetting<number>('payroll_conveyance_amount', 1600), // fixed cap ₹
  payrollMedicalAmount: () => getSetting<number>('payroll_medical_amount', 1250),    // fixed cap ₹
  payrollPfPercent: () => getSetting<number>('payroll_pf_percent', 12),          // % of basic
  payrollPfWageCeiling: () => getSetting<number>('payroll_pf_wage_ceiling', 15000),  // ₹ basic ceiling for PF
  payrollEsiPercent: () => getSetting<number>('payroll_esi_percent', 0.75),       // % of gross
  payrollEsiGrossCeiling: () => getSetting<number>('payroll_esi_gross_ceiling', 21000),// gross ≤ this → ESI applies
  payrollProfessionTax: () => getSetting<number>('payroll_profession_tax', 200),     // fixed ₹
  payrollProfessionTaxThreshold: () => getSetting<number>('payroll_profession_tax_threshold', 15000),
  payrollTdsPercent: () => getSetting<number>('payroll_tds_percent', 5),          // % above exempt slab
  payrollTdsAnnualThreshold: () => getSetting<number>('payroll_tds_annual_threshold', 500000),
  payrollTdsMonthlyExempt: () => getSetting<number>('payroll_tds_monthly_exempt', 41667),

  // ---- Payroll: LOP (Loss of Pay) policy ----
  // Company holidays / office-closed days: JSON array of "YYYY-MM-DD".
  // These days are NOT counted as working days, so they are never deducted.
  companyHolidays: () => getSetting<string[]>('company_holidays', []),
  // How many leaves in a month are PAID. Anything beyond this is LOP.
  payrollPaidLeavesPerMonth: () => getSetting<number>('payroll_paid_leaves_per_month', 1),
  // Late-mark policy: every N late punch-ins = 1 half day (0.5 day) LOP.
  payrollLatesPerHalfDay: () => getSetting<number>('payroll_lates_per_halfday', 4),
  // Half-day attendance = how much LOP (0.5 = half salary for that day).
  payrollHalfDayLop: () => getSetting<number>('payroll_halfday_lop', 0.5),
  // When generating for the CURRENT month, don't count future dates as absent.
  payrollCountFutureDays: () => getSetting<boolean>('payroll_count_future_days', false),
}