// src/hooks/useAuth.ts
'use client'
import { createContext, useContext, useState, useEffect, useCallback, ReactNode } from 'react'
import { useRouter } from 'next/navigation'
import toast from 'react-hot-toast'
import { getImpersonationToken, clearImpersonationToken, impersonationHeaders } from '@/lib/impersonation'
import { checkPermission } from '@/lib/permissions'

export interface AuthUser {
  id: string
  email: string
  name: string
  role: string
  avatar?: string
  phone?: string
  employee?: {
    id: string
    employeeId: string
    department?: { id: string, name: string }
    position?: string
    salary?: number
  }
  impersonatedBy?: string | null
  impersonatedByName?: string | null
  /** Custom permission role, when one is attached. */
  appRole?: { id: string; key: string; name: string } | null
  /** Effective permission list resolved server-side in /api/auth/me. */
  permissions?: string[]
}

interface AuthContextType {
  user: AuthUser | null
  loading: boolean
  login: (email: string, password: string) => Promise<{ success: boolean; requiresOtp?: boolean; email?: string }>
  verifyLoginOtp: (email: string, otp: string) => Promise<boolean>
  logout: () => Promise<void>
  refreshUser: () => Promise<void>
  hasRole: (...roles: string[]) => boolean
  isAtLeast: (role: string) => boolean
  /** Permission check — "clients.create". `<module>.manage` implies everything. */
  can: (permission: string) => boolean
  canAny: (...permissions: string[]) => boolean
  permissions: string[]
  isImpersonating: boolean
  exitImpersonation: () => void
}

const ROLE_HIERARCHY: Record<string, number> = {
  SUPER_ADMIN: 7, ADMIN: 6, MANAGER: 5, EMPLOYEE: 4,
  TELECALLER: 3, MARKETING_EXECUTIVE: 2, CLIENT: 1,
}

export const AuthContext = createContext<AuthContextType>({} as AuthContextType)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null)
  const [loading, setLoading] = useState(true)
  const router = useRouter()

  const fetchUser = useCallback(async () => {
    try {
      const res = await fetch('/api/auth/me', { credentials: 'include', cache: 'no-store', headers: impersonationHeaders() })
      if (res.ok) {
        const data = await res.json()
        setUser(data)
      } else if (res.status === 401) {
        setUser(null)
      }
      // Any other status (500/502/gateway timeout) -> keep the current session
      // in state instead of wiping it. Nulling the user on every hiccup is what
      // made the CRM look like it randomly logged itself out.
    } catch {
      // Network blip / offline -> do NOT clear the session.
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchUser()
  }, [fetchUser])

  const login = async (email: string, password: string) => {
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      })
      const data = await res.json()
      if (!res.ok) {
        toast.error(data.error || 'Login failed')
        return { success: false }
      }
      if (data.requiresOtp) {
        toast.success(`Verification code sent to ${data.email}`)
        return { success: false, requiresOtp: true, email: data.email }
      }
      setUser(data.user)
      toast.success(`Welcome back, ${data.user.name}!`)
      return { success: true }
    } catch {
      toast.error('Network error')
      return { success: false }
    }
  }

  const verifyLoginOtp = async (email: string, otp: string): Promise<boolean> => {
    try {
      const res = await fetch('/api/auth/verify-login-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, otp }),
      })
      const data = await res.json()
      if (!res.ok) {
        toast.error(data.error || 'Verification failed')
        return false
      }
      setUser(data.user)
      toast.success(`Welcome back, ${data.user.name}!`)
      return true
    } catch {
      toast.error('Network error')
      return false
    }
  }

  const logout = async () => {
    // Impersonating: the shared cookie is the admin's own real session —
    // clearing it here would log the admin out of every other tab too.
    // "Logout" from an impersonation tab should only mean "stop viewing as
    // this employee".
    if (getImpersonationToken()) { exitImpersonation(); return }
    await fetch('/api/auth/logout', { method: 'POST' })
    setUser(null)
    router.push('/login')
  }

  const exitImpersonation = () => {
    clearImpersonationToken()
    setUser(null)
    // Falls back to the admin's own cookie session on the next load —
    // no separate admin fetch needed, /api/auth/me just resolves normally.
    window.location.href = '/dashboard'
  }

  const refreshUser = fetchUser

  const hasRole = (...roles: string[]) => !!user && roles.includes(user.role)

  const isAtLeast = (role: string) => {
    if (!user) return false
    return (ROLE_HIERARCHY[user.role] || 0) >= (ROLE_HIERARCHY[role] || 0)
  }

  const permissions = user?.permissions || []
  const can = (permission: string) => {
    if (!user) return false
    return checkPermission(permissions, permission, user.role)
  }
  const canAny = (...list: string[]) => list.some(p => can(p))

  return (
    <AuthContext.Provider value={{ user, loading, login, verifyLoginOtp, logout, refreshUser, hasRole, isAtLeast, can, canAny, permissions, isImpersonating: !!user?.impersonatedBy, exitImpersonation }}>
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => useContext(AuthContext)
