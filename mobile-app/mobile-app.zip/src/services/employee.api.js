import { AxiosInstance } from '../lib/Axios.instance';

// Helper: object -> query string (drops empty values)
const qs = (params) => {
  const p = new URLSearchParams();
  Object.entries(params || {}).forEach(([k, v]) => {
    if (v !== undefined && v !== null && v !== '' && v !== 'all') p.append(k, v);
  });
  const q = p.toString();
  return q ? `?${q}` : '';
};

// All employee (marketing person) calls hit the new CRM /mobile/* endpoints.
export const EmployeeAPI = {
  // Auth
  login: (email, password) => AxiosInstance.post('/mobile/auth/login', { email, password }),

  // Dashboard + profile
  getDashboard: () => AxiosInstance.get('/mobile/dashboard'),
  getProfile: () => AxiosInstance.get('/mobile/profile'),
  getVisitingCard: () => AxiosInstance.get('/mobile/visiting-card'),
  updateProfile: (data) => AxiosInstance.patch('/mobile/profile', data),
  changePassword: (data) => AxiosInstance.post('/mobile/profile/change-password', data),
  uploadImage: (dataUrl, folder = 'avatars') => AxiosInstance.post('/upload', { dataUrl, folder }),

  // Today's + upcoming birthdays/work-anniversaries
  getCelebrations: () => AxiosInstance.get('/mobile/celebrations'),
  
  // Attendance / tracking session
  getAttendanceStatus: () => AxiosInstance.get('/mobile/attendance/status'),
  checkIn: (loc) => AxiosInstance.post('/mobile/attendance/check-in', loc || {}),
  checkOut: (loc) => AxiosInstance.post('/mobile/attendance/check-out', loc || {}),

  // Clients
  // params: { range, date, dateFrom, dateTo, status, expiry, search }
  getClients: (params) => AxiosInstance.get(`/mobile/clients${qs(params)}`),
  createClient: (data) => AxiosInstance.post('/mobile/clients', data),
  // roles: comma-separated, e.g. 'TELECALLER,MANAGER'
  getUsersByRole: (roles) => AxiosInstance.get(`/users/by-role?roles=${roles}`),
  getClientById: (id) => AxiosInstance.get(`/mobile/clients/${id}`),

  // Packages + service assignment
  getPackages: () => AxiosInstance.get('/mobile/packages'),
  assignService: (data) => AxiosInstance.post('/mobile/assign-service', data),

  // Proposals & Invoices (client deal paperwork)
  getProposals: (idOrParams) => {
    const q = typeof idOrParams === 'string'
      ? `?clientId=${idOrParams}`
      : idOrParams?.leadId ? `?leadId=${idOrParams.leadId}`
      : idOrParams?.clientId ? `?clientId=${idOrParams.clientId}`
      : ''
    return AxiosInstance.get(`/mobile/proposals${q}`)
  },
  createProposal: (data) => AxiosInstance.post('/mobile/proposals', data),
  // "Save & Send to Client" — emails + WhatsApps the proposal, same as the web builder.
  sendProposal: (id, data) => AxiosInstance.post(`/proposals/${id}/send`, data),
  getInvoices: (clientId) => AxiosInstance.get(`/mobile/invoices${clientId ? `?clientId=${clientId}` : ''}`),
  createInvoice: (data) => AxiosInstance.post('/mobile/invoices', data),

  // Payments Received
  getPayments: (clientId) => AxiosInstance.get(`/mobile/payments${clientId ? `?clientId=${clientId}` : ''}`),
  collectPayment: (data) => AxiosInstance.post('/mobile/payments', data),

  // Meetings assigned to this marketing executive
  // params: { range, date, dateFrom, dateTo, status, search, lat, lng }
  // Send lat/lng to get distance + ETA for each meeting
  getMeetings: (params) => AxiosInstance.get(`/mobile/meetings${qs(params)}`),
  getMeetingById: (id) => AxiosInstance.get(`/mobile/meetings/${id}`),
  logMeetingActivity: (id, data) => AxiosInstance.post(`/mobile/meetings/${id}/activity`, data),
  markMeetingDone: (id, data) => AxiosInstance.post(`/mobile/meetings/${id}/done`, data),
  noAnswerMeeting: (id, data) => AxiosInstance.post(`/mobile/meetings/${id}/no-answer`, data),
  rescheduleMeeting: (id, data) => AxiosInstance.post(`/mobile/meetings/${id}/reschedule`, data),
  // Free/booked office-hours slots for MY calendar on a given date, so the
  // reschedule sheet can offer real slots instead of a raw time field.
  getMeetingSlots: (id, date) => AxiosInstance.get(`/mobile/meetings/${id}/slots`, { params: { date } }),
  // Slot-by-slot view of my own day(s) — every office slot with whatever
  // meeting sits in it, so the whole day is visible at a glance.
  getMySchedule: (params) => AxiosInstance.get('/mobile/meetings/schedule', { params }),
  // Cancel an assigned meeting. `notes` is MANDATORY — it is what the
  // telecaller / lead creator sees in the "re-assign needed" notification.
  cancelMeeting: (id, data) => AxiosInstance.post(`/mobile/meetings/${id}/cancel`, data),
  closeMeeting: (id, data) => AxiosInstance.post(`/mobile/meetings/${id}/close`, data),

  // Visits
  // params: { range, status, date, dateFrom, dateTo, search }
  getVisits: (params) => AxiosInstance.get(`/mobile/visits${qs(params)}`),
  createVisit: (data) => AxiosInstance.post('/mobile/visits', data),
  startVisit: (id, loc) => AxiosInstance.post(`/mobile/visits/${id}/start`, loc || {}),
  completeVisit: (id, loc) => AxiosInstance.post(`/mobile/visits/${id}/complete`, loc || {}),

  // Location ping (used internally by LocationTracker too)
  sendLocation: (pings) => AxiosInstance.post('/mobile/location', { pings }),

  // Leaves
  getLeaves: () => AxiosInstance.get('/mobile/leaves'),
  applyLeave: (data) => AxiosInstance.post('/mobile/leaves', data),
  getLeaveBalance: () => AxiosInstance.get('/mobile/leaves/balance'),

  // Public share links (proposal / invoice / payment receipt) — for direct browser redirect
  getProposalShareLink: (proposalId) => AxiosInstance.get(`/proposals/${proposalId}/share-link`),
  getInvoiceShareLink: (invoiceId) => AxiosInstance.get(`/invoices/${invoiceId}/share-link`),
  getPaymentReceiptLink: (paymentId) => AxiosInstance.get(`/payments/receipt-link/${paymentId}`),
};